﻿SaturnX Build Structure
=======================

The current Debug executable is located at:

build\debug\bin\Debug\SaturnX.exe

The structure is currently ugly because CMake/Visual Studio
generates nested configuration directories.

Do not move SaturnX.exe manually.

PROJECT ROOT:

build\debug\bin\Debug\
├── SaturnX.exe

runtime\
├── cores\ <------ HERE IS BEEETLE-SATURN.DLL!!!
      └── beetle-saturn.dll           
├── system\ <------ HERE IS BIOS!!!
└── saves\ <------ HERE IS YOUR SAVES!!!
 rom\ <------ HERE IS YOUR GAMES!!!

P.S. 100% working BIOS for SaturnX here: https://archive.org/download/mame-0.221-roms-merged/saturn.zip/mpr-17933.bin
